# Uses python3
import sys

def fibonacci_sum(n):
    # write your code here
    return 0

if __name__ == '__main__':
    input = sys.stdin.read()
    n = int(input)
    print(fibonacci_sum(n))
