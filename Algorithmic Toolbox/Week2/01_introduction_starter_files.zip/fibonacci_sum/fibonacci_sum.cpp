#include <iostream>

int fibonacci_sum(long long n) {
  //write your code here
  return 0;
}

int main() {
  long long n = 0;
  std::cin >> n;
  std::cout << fibonacci_sum(n);
}
