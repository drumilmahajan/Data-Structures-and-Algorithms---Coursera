import java.util.*;

public class FibonacciSum {
    private static int getFibonacciSum(long n) {
        return 0;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        long n = scanner.nextLong();
        int c = getFibonacciSum(n);
        System.out.println(c);
    }
}

